# PPP-Project
A mini-project for Principles of Procedimental Programing subject of the Informatics engineering course - University of Coimbra

-The Code is written is english but the comments and the manual are in Portuguese!!
